package com.example.myapp4.presentation

import android.app.Application

class NotesApp : Application()